# Utility Functions
